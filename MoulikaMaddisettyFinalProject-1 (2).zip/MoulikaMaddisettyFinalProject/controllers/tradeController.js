//Get /newTrade.ejs
const express = require('express');
const model = require('../models/item');
const { redirect } = require('express/lib/response');
const save_model = require("../models/tradeSave");
const offer_model = require("../models/tradeOffer");



exports.newTrade = (req,res)=>{
    res.render('./trades/newTrade');
      };


    /*  exports.EditForm = (req,res)=>{
        res.render('./trades/EditForm');
          };*/

          //products
          exports.products = (req,res,next)=>{
            //let trades=model.find();
           //res.render('./trades/trades',{trades});
           model.find()
          .then(stories=>res.render('./trades/trades',{stories}))
          .catch(err=>next(err));
              };


            /*  exports.create = (req,res) => {
                // res.send('Created a new trade ')
                let datalist = req.body
                model.save(datalist)
                res.redirect('/trades')
            } */

            exports.create = (req, res, next)=>{
              //res.send('Created a new story');
              let story = new model(req.body); 
              story.author = req.session.user;
              story.status = "Available";
              story.offerItem = "";
              story.Saved = false;
              story.Offered = false;
              story.save() // insert the document to the db
              .then((story)=> {
                  //console.log(story);
                  req.flash("success", "Succesfully created a new Trade");
                  res.redirect('/trades');
              } )
              .catch(err=>{
                  if(err.name ==='ValidationError') {
                      err.status = 400;
                      req.flash('error', err.message);
            res.redirect('back');
                  }
                  next(err);
              });
          };
    
    //Get /trade.ejs
    /*exports.trade = (req,res,next)=>{
        //res.render('./trades/trade');
        let id=req.params.id;
        let product=model.findById(id);
        if(product){
          res.render('./trades/trade',{product})
        }
        else{
        //res.status(404).send('cananot find the product with id' +id);
        let err = new Error('Cannot find trade with id ' + id);
        err.status = 404;
        next(err);
        }
        }; */

        exports.trade = (req, res, next)=>{
            
            let id = req.params.id;
            model.findById(id).populate('author', 'firstName lastName')
          .then(story=>{
              if(story) {
                 return res.render('./trades/trade', {story});
              } else {
                  let err = new Error('Cannot find a trade with id ' + id);
                  err.status = 404;
                  next(err);
              }
          })
          .catch(err=>next(err));  
      };
    
      /*  exports.edit=(req,res,next) =>{
          let id=req.params.id;
          let product=model.findById(id);
          if(product){
            res.render('./trades/Edit',{product})
          }
          else{
            //res.status(404).send('cananot find the product with id' +id);
            let err = new Error('Cannot find trade with id ' + id);
            err.status = 404;
            next(err);
            }
        
       }; */

      

    exports.edit = (req, res, next) => {
      let id = req.params.id;
      model
        .findById(id)
        .then((story) => {
          res.render("./trades/Edit", { story });
        })
        .catch((err) => {
          next(err);
        });
    };

       //update

      /* exports.update=(req,res,next) => {
        let product=req.body;
        let id=req.params.id;
        if(model.updateById(id,product)){
          res.redirect('/trades/'+ id);
        }

        else{
          //res.status(404).send('cananot find the product with id' +id);
          let err = new Error('Cannot find trade with id ' + id);
          err.status = 404;
          next(err);
          }
     }; */

     exports.update = (req, res, next) => {
      let story = req.body;
      let id = req.params.id;
      model
        .findByIdAndUpdate(id, story, { useFindAndModify: false,runValidators: true,})
        .then((story) => {
          req.flash("success", "Succesfully updated a trade ");
          res.redirect("/trades/" + id);
        })
        .catch((err) => {
          if (err.name === "ValidationError") {
            err.status = 400;
          }
          next(err);
        });
    };

    
     //delete

   /*  exports.delete = (req,res,next) => {
      // res.send('delete a exiting trade ', req.params.id)
      let id = req.params.id
      if(model.deleteById(id)){
          res.redirect('/trades')
      }
      else{
        //res.status(404).send('cananot find the product with id' +id);
        let err = new Error('Cannot find trade with id ' + id);
        err.status = 404;
        next(err);
        }
  } */

  exports.delete = (req, res, next) => {
    let id = req.params.id;
    model
      .findById(id)
      .then((item) => {
        let name = item.offerItem;
        Promise.all([
          offer_model.findOneAndDelete(
            { title: name },
            { useFindAndModify: false }
          ),
          model.findByIdAndDelete(id, { useFindAndModify: false }),
          model.findOneAndUpdate({title:name},{status:"Available", Offered:false})
        ])
          .then((results) => {
            const [offer, item, item2] = results;
          })
          .catch((err) => {
            next(err);
          });
        req.flash("success", "Succesfylly deleted a trade");
        res.redirect("/trades");
      })
      .catch((err) => {
        next(err);
      });
  };
    //Get /trades.ejs
    /*exports.trades = (req,res)=>{
        res.render('./trades/trades');
        };*/

//Adding item to wishlist
exports.save = (req, res, next) => {
    console.log("in save");
    let id = req.params.id;
    model
      .findByIdAndUpdate(
        id,
        { Saved: true },
        {
          useFindAndModify: false,
          runValidators: true,
        }
      )
      .then((item) => {
        let name = item.title;
        let newSaveItem = new save_model({
          title: item.title,
          category: item.category,
          status: item.status,
        });
        newSaveItem.SavedBy = req.session.user;
        save_model
          .findOne({ title: name })
          .then((item) => {
            if (!item) {
              newSaveItem
                .save()
                .then((newSaveItem) => {
                  req.flash("success", "Trade Added to Watchlist");
                  res.redirect("/users/profile");
                })
                .catch((err) => {
                  if (err.name === "ValidationError") {
                    err.status = 400;
                  }
                  next(err);
                });
            } else {
              req.flash("error", "Trade is already saved");
              res.redirect("/save");
            }
          })
          .catch((err) => {
            next(err);
          });
      })
      .catch((err) => {
        next(err);
      });
  };
  
//Removing item from wishlist

  exports.savedelete = (req, res, next) => {
    console.log("in save delete");
    let id = req.params.id;
    model
      .findByIdAndUpdate(id, { Saved: false })
      .then((story) => {
        let name = story.title;
        save_model
          .findOneAndDelete({ title: name }, { useFindAndModify: false })
          .then((save) => {
            req.flash("success", "Trade removed from the watchlist");
            res.redirect("back");
          })
          .catch((err) => {
            next(err);
          });
      })
      .catch((err) => {
        next(err);
      });
  };

  //Trading an item

  exports.showtrade = (req, res, next) => {
    console.log("in trade");
    let user = req.session.user;
    iD = req.params.id;
    model
      .findByIdAndUpdate(
        iD,
        { status: "Offer Pending", Offered: true },
        {
          useFindAndModify: false,
          runValidators: true,
        }
      )
      .then((item) => {
        let newOfferItem = new offer_model({
          title: item.title,
          status: "Offer Pending",
          category: item.category,
          OfferedBy: user,
        });
        newOfferItem.save().then((offer) => {
          model
            .find({ author: user})
            .then((items) => {
              res.render("./trades/productTrade", { items });
            })
            .catch((err) => {
              next(err);
            });
        });
      })
      .catch((err) => {
        next(err);
      })
      .catch((err) => {
        next(err);
      });
  };
  
  
  exports.tradeitem = (req, res, next) => {
    console.log("in trade item");
    let id = req.params.id;
    let user = req.session.user;
    Promise.all([
      model.findByIdAndUpdate(
        id,
        { status: "Offer Pending" },
        {
          useFindAndModify: false,
          runValidators: true,
        }
      ),
      offer_model.findOne({ OfferedBy: user }).sort({ _id: -1 }),
    ])
      .then((results) => {
        const [item, Offered] = results;
        let name = Offered.title;
        model
          .findByIdAndUpdate(
            id,
            { offerItem: name },
            {
              useFindAndModify: false,
              runValidators: true,
            }
          )
          .then((item) => {
            req.flash("success", "Trade offer sucessfully created for a Trade");
            res.redirect("/users/profile");
          })
          .catch((err) => {
            next(err);
          });
      })
      .catch((err) => {
        next(err);
      });
  };

  // Manage trade

  exports.manage = (req, res, next) => {
    console.log("in manage offer function");
    let id = req.params.id;
    let user = req.session.user;
    model
      .findById(id)
      .then((item) => {
        if (item.offerItem === "") {
          let name = item.title;
          model
            .findOne({ offerItem: name })
            .then((item) => {
              res.render("./trades/manage", { item });
            })
            .catch((err) => {
              next(err);
            });
        } else {
          let name = item.offerItem;
          offer_model
            .findOne({ title: name })
            .then((offer) => {
              res.render("./trades/manageTrade", { item, offer });
            })
            .catch((err) => {
              next(err);
            });
        }
      })
      .catch((err) => {
        next(err);
      });
  };

  //deleting the manage offer

  exports.deletemanageoffer = (req, res, next) => {
    console.log("in manage-offer delete");
    let id = req.params.id;
    model
      .findByIdAndUpdate(id, { status: "Available", offerItem: "" })
      .then((item) => {
        let name = item.offerItem;
        Promise.all([
          offer_model.findOneAndDelete({ title: name }),
          model.findOneAndUpdate(
            { title: name },
            { status: "Available", Offered: false }
          ),
        ])
          .then((results) => {
            const [offer, item] = results;
            req.flash("success", "Trade offer is cancelled");
            res.redirect("/users/profile");
          })
          .catch((err) => {
            next(err);
          });
      })
      .catch((err) => {
        next(err);
      });
  };

  //delete the offer item from profile

  exports.deleteoffer = (req, res, next) => {
    console.log("in offer delete");
    let id = req.params.id;
    model
      .findByIdAndUpdate(
        id,
        { status: "Available", Offered: false },
        {
          useFindAndModify: false,
          runValidators: true,
        }
      )
      .then((item) => {
        let name = item.title;
  
        Promise.all([
          model.findOneAndUpdate(
            { offerItem: name },
            { status: "Available", offerItem: "" }
          ),
          offer_model.findOneAndDelete(
            { title: name },
            { useFindAndModify: false }
          ),
        ])
          .then((results) => {
            const [item, offer] = results;
            req.flash("success", "Trade offer has been cancelled");
            res.redirect("/users/profile");
          })
          .catch((err) => {
            next(err);
          });
      })
      .catch((err) => {
        next(err);
      });
  };

  //Accepting the offer item
  exports.accept = (req, res, next) => {
    console.log("in accept");
    let id = req.params.id;
    model
      .findByIdAndUpdate(
        id,
        { status: "Traded" },
        {
          useFindAndModify: false,
          runValidators: true,
        }
      )
      .then((item) => {
        let name = item.offerItem;
  
        Promise.all([
          model.findOneAndUpdate(
            { title: name },
            { status: "Traded" },
            {
              useFindAndModify: false,
              runValidators: true,
            }
          ),
          offer_model.findOneAndDelete(
            { title: name },
            { useFindAndModify: false }
          ),
        ])
          .then((results) => {
            const [item, offer] = results;
            req.flash("success", "Trade offer has been successfully accepted");
            res.redirect("/users/profile");
          })
          .catch((err) => {
            next(err);
          });
      })
      .catch((err) => {
        next(err);
      });
  };

  //Rejecting offer Item

  exports.reject = (req, res, next) => {
    console.log("in reject");
    let id = req.params.id;
    model
      .findByIdAndUpdate(
        id,
        { status: "Available", offerItem: "" },
        {
          useFindAndModify: false,
          runValidators: true,
        }
      )
      .then((item) => {
        let name = item.offerItem;
        Promise.all([
          model.findOneAndUpdate(
            { title: name },
            { status: "Available", Offered:false },
            {
              useFindAndModify: false,
              runValidators: true,
            }
          ),
          offer_model.findOneAndDelete({ title: name }),
        ])
          .then((results) => {
            const [item, offer] = results;
            let name = item.title;
            let status = item.status;
            if (item.Saved) {
              save_model
                .findOneAndUpdate(
                  { title: name },
                  { status: status },
                  {
                    useFindAndModify: false,
                    runValidators: true,
                  }
                )
                .then((save) => {})
                .catch((err) => {
                  next(err);
                });
            }
            req.flash("success", "Trade offer has been rejected");
            res.redirect("/users/profile");
          })
          .catch((err) => {
            next(err);
          });
      })
      .catch((err) => {
        next(err);
      });
  };




