const express=require('express');
const maincontroller = require('../controllers/mainController');
const mainrouter=express.Router();

//mainrouter.get('/',(req,res)=>{res.send("send infromation about newTrade");});

mainrouter.get('/',maincontroller.index);

mainrouter.get('/index', maincontroller.index);

//mainrouter.get('/newTrade.ejs',(req,res)=>{res.send("send infromation about newTrade");});

//mainrouter.get('/newTrade.ejs',maincontroller.newTrade);

//mainrouter.get('/trade.ejs',(req,res)=>{res.send("send infromation about Trade");});

//mainrouter.get('/trade.ejs',maincontroller.trade);

//mainrouter.get('/trades.ejs',(req,res)=>{res.send("send infromation about Trades");});

//mainrouter.get('/trades.ejs',maincontroller.trades);

//mainrouter.get('/error.ejs',(req,res)=>{res.send("send infromation about error");});

//mainrouter.get('/contact.ejs',(req,res)=>{res.send("send infromation about contact");});

mainrouter.get('/contact',maincontroller.contact);



//mainrouter.get('/about.ejs',(req,res)=>{res.send("send infromation about page");});

mainrouter.get('/about',maincontroller.about);

module.exports=mainrouter;