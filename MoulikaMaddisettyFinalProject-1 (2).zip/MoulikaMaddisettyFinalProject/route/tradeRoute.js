const express=require('express');
const tradecontroller = require('../controllers/tradeController');
const traderouter=express.Router();
const {isLoggedIn,isAuthor,isValidUser,isOfferedBy} = require('../middlewares/auth');
const {validateId, validateitem,validationResult,saveitem} = require('../middlewares/validator');

traderouter.get('/newTrade',isLoggedIn,tradecontroller.newTrade);

//traderouter.get('/EditForm',tradecontroller.EditForm);

traderouter.get('/',tradecontroller.products);

//Get /trade
traderouter.get('/:id',validateId,tradecontroller.trade);

//Get // edit form
traderouter.get('/:id/edit',validateId, isLoggedIn, isAuthor,tradecontroller.edit);


//new

traderouter.post('/',isLoggedIn,validateitem,validationResult,tradecontroller.create);

//traderouter.get('/trades',tradecontroller.trades);

//update

traderouter.put('/:id',validateId, isLoggedIn, isAuthor,validateitem,validationResult,tradecontroller.update);

//delete

traderouter.delete('/:id',validateId, isLoggedIn, isAuthor,tradecontroller.delete);

//Add data to watch list
traderouter.post( "/:id/save", validateId, isLoggedIn,validationResult, tradecontroller.save);

// To unsave the saved trade
traderouter.delete( "/:id/savedelete", validateId, isLoggedIn, isValidUser, tradecontroller.savedelete);

// Trade item route
traderouter.get("/:id/showtrade", validateId, isLoggedIn, tradecontroller.showtrade);

// Trade item route
traderouter.get("/:id/tradeitem", isLoggedIn, tradecontroller.tradeitem);

// Manage item
traderouter.get("/:id/manage", validateId, isLoggedIn, tradecontroller.manage);

//deleting the manage offer item

traderouter.delete( "/:id/deletemanageoffer",validateId, tradecontroller.deletemanageoffer);

//canceling the offer item from profile

traderouter.delete( "/:id/deleteoffer",validateId,  isLoggedIn, isOfferedBy,tradecontroller.deleteoffer);

//Accept the offeritem

traderouter.get("/:id/accept", validateId, isLoggedIn, tradecontroller.accept);

//Reject the offeritem

traderouter.get("/:id/reject", validateId, isLoggedIn, tradecontroller.reject);

module.exports=traderouter;