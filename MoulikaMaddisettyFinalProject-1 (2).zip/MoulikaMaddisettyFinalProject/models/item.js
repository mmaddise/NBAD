const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const productSchema = new Schema({
        category:{type:String, required:[true,'category is required']},
        title: {type: String, required:[true,'title is required']},
        author: {type: Schema.Types.ObjectId, ref:'User'},
        status:{type:String, required:[true,'status is required']},
        imageurl:{type:String, required:[true,'imageurl is required']},
        details:{type:String, required:[true,'details are required'],
                minlength:[10,'the content should have atleast 10 characters']},
        offerItem: { type: String },
        Saved: { type: Boolean },
        Offered: { type: Boolean }
    },
{timestamps: true}
);


const Story = mongoose.model('Story', productSchema);

module.exports = mongoose.model('Story', productSchema);